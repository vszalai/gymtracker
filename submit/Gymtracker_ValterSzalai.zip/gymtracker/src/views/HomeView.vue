<script></script>

<template>
  <div class="relative h-[calc(100vh-4rem)]">
    <div class="absolute inset-0 bg-cover bg-center bg-[url(../../image.jpg)]"></div>
    <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
    <div class="relative flex justify-center items-center h-full">
      <h1 class="text-5xl text-white">GymTracker</h1>
    </div>
  </div>
</template>
